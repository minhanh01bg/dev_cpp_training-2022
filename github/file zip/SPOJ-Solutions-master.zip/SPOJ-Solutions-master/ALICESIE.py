T = int(input())
for _ in range(T):
    print((int(input()) + 1) >> 1)