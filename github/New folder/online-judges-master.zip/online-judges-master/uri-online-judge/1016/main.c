/*
Distância
https://www.urionlinejudge.com.br/judge/pt/problems/view/1016
*/

#include <stdio.h>

int main (void) {
  double distancia;
  
  scanf("%lf", &distancia);
  
  printf("%.0f minutos\n", distancia * 2);
  
  return 0;
}
