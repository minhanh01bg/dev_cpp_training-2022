# solution-spoj-cf

Like the title mentioned, I will upload problem statement translations (from English to Vietnamese and vise-versa), solutions and code examples of SPOJ and Codeforces problems I have done. No credit is required, but please don't claim my codes as your own.

Như tiêu đề, mình sẽ upload bản dịch đề bài (từ tiếng Anh sang tiếng Việt và ngược lại), lời giải và code mẫu của các bài tập SPOJ và Codeforces mình đã hoàn thành. Không cần phải credit mình, nhưng đừng nhận code của mình là code của bạn.
