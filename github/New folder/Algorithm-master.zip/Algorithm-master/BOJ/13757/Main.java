/* 
 * Author: Kim Min-Ho (ISKU)
 * Date: 2016.11.11
 * email: minho1a@hanmail.net
 * 
 * https://github.com/ISKU/Algorithm
 * https://www.acmicpc.net/problem/13757
 */

public class Main {
	public static void main(String... args) {
        System.out.println("빼빼로 먹고 싶어요!");
    }
}