
#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
int main()
{
	ll n;
	#ifndef ONLINE_JUDGE
freopen("input.txt","r",stdin);
freopen("output.txt","w",stdout);
#endif
scanf("%lld",&n);
    switch(n) {
        case 0 : printf("1"); break;
        case 1 : printf("3"); break;             
        case 2 : printf("3"); break;       
        case 3 : printf("12"); break;             
        case 4 : printf("12"); break;             
        case 5 : printf("60"); break;             
        case 6 : printf("540"); break;
        case 7 : printf("1080"); break;
        case 8 : printf("6480"); break;
        case 9 : printf("32400"); break;
        case 10: printf("97200"); break;
        case 11: printf("486000"); break;
        case 12: printf("3888000"); break;
        case 13: printf("34992000"); break;
        case 14: printf("244944000"); break;
        case 15: printf("2204496000"); break;
        case 16: printf("6613488000"); break;
        case 17: printf("13226976000"); break;
        case 18: printf("39680928000"); break;
        case 19: printf("317447424000"); break;
        case 20: printf("1269789696000"); break;
        case 21: printf("7618738176000"); break;
        case 22: printf("15237476352000"); break;
        case 23: printf("91424858112000"); break;
        case 24: printf("365699432448000"); break;
        case 25: printf("1097098297344000"); break;
        case 26: printf("3291294892032000"); break;
        case 27: printf("26330359136256000"); break;
        case 28: printf("78991077408768000"); break;
        case 29: printf("157982154817536000"); break;
        case 30: printf("1105875083722752000"); break;
        case 31: printf("9952875753504768000"); break;
    }
}



