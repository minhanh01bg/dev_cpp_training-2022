#include<bits/stdc++.h>
using namespace std;
int main(){  int a,b;
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);

    while(cin>>a>>b)
    {
        cout<<a+b<<endl;
    }
return 0;
}
