#include <bits/stdc++.h>

using namespace std;

int main() {
    std::ios::sync_with_stdio(false); 
    cin.tie(nullptr);
    
    int N, K;
    cin >> N >> K;
    cout << N - K + 1 << "\n";
    return 0;
}