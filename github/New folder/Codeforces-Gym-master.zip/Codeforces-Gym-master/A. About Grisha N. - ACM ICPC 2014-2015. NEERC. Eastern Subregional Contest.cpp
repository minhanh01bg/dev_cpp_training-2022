#include <iostream>
using namespace std;
int main(){
int f;
cin >> f;
cout<<(12-f > 5 ? "NO\n":"YES\n");
    return 0;
}