#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

int main()
{
    char ax[3][3];
    int i,j;
    for(i=1;i<=3;i++)
        for(j=1;j<=3;j++)
    {
        gets(ax);
    }
}
