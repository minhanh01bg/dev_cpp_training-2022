# VNOI
Repo này bao gồm bài giải của gần 320 bài tập mình đã luyện tập trên http://vn.spoj.com/ (trong khoảng 2 năm THPT). Mỗi thư mục chứa một file code (đuôi .PAS) và một file đề bài (có tên là Problem). Một số thư mục có kèm theo file hướng dẫn giải (có tên là Solution), một số thư mục thì không. Và mình cũng không có ý định bổ sung Solution cho những thư mục còn thiếu.
