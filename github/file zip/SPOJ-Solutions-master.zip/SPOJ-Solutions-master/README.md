# SPOJ-Solutions
Solutions to my solved SPOJ questions.\
Please refer to these solutions **only** when you have tried the problem yourself and you are not able to come up with any approach, also feel free to report any bugs and contribute your solutions to this repo.
<br>
My profile link [SPOJ](https://www.spoj.com/users/karan_batra/)

### Contributions
- Fork the repo and create PR for newly added solutions
