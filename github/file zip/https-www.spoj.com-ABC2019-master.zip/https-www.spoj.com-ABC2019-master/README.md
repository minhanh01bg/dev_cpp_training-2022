## solution for spoj 2019, [you can follow in here](https://www.spoj.com/ABC2019/problems/main/)

:fish: :boom:

```
Some clone, some code!
```
