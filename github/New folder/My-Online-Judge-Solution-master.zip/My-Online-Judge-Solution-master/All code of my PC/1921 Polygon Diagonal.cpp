#include<bits/stdc++.h>
using namespace std;
int main()
{
    long long n;
    while(cin>>n)
    {
        cout<<(n*(n-3))/2<<endl;
    }
    return 0;
}
