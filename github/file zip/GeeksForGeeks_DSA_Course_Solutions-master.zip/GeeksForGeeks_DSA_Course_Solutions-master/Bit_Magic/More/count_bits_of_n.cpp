#include<bits/stdc++.h>
using namespace std;

int main(){
    int n;
    cin>>n;
    printf("%d\n", (int) floor(log2(n)) + 1);
}