#include <iostream>
using namespace std;
main()
{
	int n;
	cin >> n;
	cout << n << " ";
	for (int i = 1; i < n; i++) cout << i << " ";
}
