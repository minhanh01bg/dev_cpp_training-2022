---
layout: post
title:  "NKNUMFRE - "
categories: []
code: NKNUMFRE
src: NKNUMFRE.cpp
codeforces: https://codeforces.com/group/FLVn1Sc504/contest/274824/problem/X
---



  


Số tự nhiên có rất nhiều tính chất thú vị. Ví dụ với số 23, số đảo ngược của nó là 32. Hai số này có ước chung lớn nhất là 1. Những số như thế được gọi là số thân thiện, tức là số 23 được gọi là số thân thiện, số 32 cũng được gọi là số thân thiện.

Hãy nhập vào 2 số nguyên a,b (10≤a≤b≤30000). Hãy đếm xem trong khoảng từ a đến b (kể cả a và b) có bao nhiêu số thân thiện.

#### Dữ liệu

Bao gồm một dòng chứa 2 số a,b. Hai số được cách nhau bằng một khoảng trắng

#### Kết quả

Bao gồm một dòng là kết quả của bài toán.

#### Ví dụ

```
Input
20 30		

Output
3

```

<!--more-->

