n = int(input())
res = n//2 if not n % 2 else n//2 - n
print(res) 
