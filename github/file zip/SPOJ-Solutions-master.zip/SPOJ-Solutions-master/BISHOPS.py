while(1):
  try: 
    x=input()
    if (x==0 or x==1): print x
    else: print ((2*x)-2)
  except:
    break

