[Statements](https://vietnam-national17.kattis.com/problems)
