#include<bits/stdc++.h>
using namespace std;
int main()
{

    for(int i=1;i<=100;i++)
    {

        if(i%3==0 and i%5==0)
            cout<<"BanglaDesh"<<endl;
        else  if(i%3==0)
             cout<<"Bangla"<<endl;
        else  if(i%5==0)
             cout<<"Desh"<<endl;
       else cout<<i<<endl;
    }
    return 0;
}
