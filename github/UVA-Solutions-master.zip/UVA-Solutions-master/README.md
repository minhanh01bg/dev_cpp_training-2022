# UVA-Solutions
Solutions in c++ or Java of most UVA problems I've solved. Also includes solutions for the South America ACM-ICPC contests that I fully solved.
