for i in range(5):
   for j in range(5):
        a[i][j] = int(input())

print(a)
