#include <iostream>
using namespace std;
long a, b, res;
int main()
{
cin >> a >> b;
res = a * (b - 1) + 1;
cout << res;
}
