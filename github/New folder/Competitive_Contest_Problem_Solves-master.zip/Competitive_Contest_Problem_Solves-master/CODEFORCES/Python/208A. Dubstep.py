s = input()


print(s.replace("WUB"," "))