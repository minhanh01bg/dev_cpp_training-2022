
# Trie


## Problems and notes

1. ^ [Trie | (Insert and Search)](https://practice.geeksforgeeks.org/problems/trie-insert-and-search0651/1) [(Solution)]()
2. [Search Query for Strings](https://practice.geeksforgeeks.org/problems/search-query-for-strings5049/1) [(Solution)]()
3. [Renaming Cities](https://practice.geeksforgeeks.org/problems/renaming-cities28581833/1) [(Solution)]()
4. [Camel Case](https://practice.geeksforgeeks.org/problems/camel-case04234120/1) [(Solution)]()
5. [Contiguous Elements XOR](https://practice.geeksforgeeks.org/problems/contiguous-elements-xor4151/1) [(Solution)]()
6. ^ [Most frequent word in an array of strings](https://practice.geeksforgeeks.org/problems/most-frequent-word-in-an-array-of-strings3528/1) [(Solution)]()



## More problems


## Further reading

