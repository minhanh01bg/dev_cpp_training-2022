---
layout: posts_by_category
categories: lca
title: Last Common Ancestor - Tổ tiên chung gần nhất
permalink: /category/lca
---