#include<iostream>
#include<math.h>
using namespace std;
int main(){
	int n;
	cin>>n;
	cout<<(long long)(pow(2,n)*2)-2;
return 0;
}
 
