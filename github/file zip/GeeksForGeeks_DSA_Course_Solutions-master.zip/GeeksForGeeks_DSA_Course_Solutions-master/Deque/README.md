# Deque

## Problems and notes

1. [Deque Implementations](https://practice.geeksforgeeks.org/problems/deque-implementations/1) [(Solution)]()
2. ^ [Maximum of all subarrays of size k](https://practice.geeksforgeeks.org/problems/maximum-of-all-subarrays-of-size-k3101/1) [(Solution)]()
3. [Dequeue Traversal](https://practice.geeksforgeeks.org/problems/dequeue-traversal/1) [(Solution)]()
4. [Rotate Deque By K](https://practice.geeksforgeeks.org/problems/rotate-deque-by-k/1) [(Solution)]()
5. [Insertion in deque](https://practice.geeksforgeeks.org/problems/insertion-in-deque/1) [(Solution)]()
6. [Deque deletion](https://practice.geeksforgeeks.org/problems/deque-deletion/1) [(Solution)]()


## More problems



## Further reading
