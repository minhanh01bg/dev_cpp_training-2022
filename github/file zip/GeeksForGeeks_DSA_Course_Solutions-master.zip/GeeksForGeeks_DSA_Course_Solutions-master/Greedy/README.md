
# Greedy 


## Problems and notes

1. ^ [Activity Selection](https://practice.geeksforgeeks.org/problems/activity-selection-1587115620/1) [(Solution)]()
2. [Huffman Decoding](https://practice.geeksforgeeks.org/problems/huffman-decoding/1) [(Solution)]()
3. [Fractional Knapsack](https://practice.geeksforgeeks.org/problems/fractional-knapsack-1587115620/1) [(Solution)]()
4. [Largest number with given sum](https://practice.geeksforgeeks.org/problems/largest-number-with-given-sum-1587115620/1) [(Solution)]()
5. [Job Sequencing Problem](https://practice.geeksforgeeks.org/problems/job-sequencing-problem-1587115620/1) [(Solution)]()



## More problems



## Further reading
