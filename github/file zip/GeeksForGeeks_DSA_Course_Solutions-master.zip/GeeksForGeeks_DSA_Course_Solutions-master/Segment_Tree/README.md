
# Segment Tree


## Problems and notes

1. [Range Sum Queries](https://practice.geeksforgeeks.org/problems/range-sum-queries2353/1) [(Solution)]()
2. [Range Min Max Queries](https://practice.geeksforgeeks.org/problems/range-min-max-queries4557/1) [(Solution)]()
3. [Range Longest Correct Bracket Subsequence Queries](https://practice.geeksforgeeks.org/problems/range-queries-for-longest-correct-bracket-subsequence4719/1) [(Solution)]()
4. [Range GCD Queries](https://practice.geeksforgeeks.org/problems/range-gcd-queries3654/1) [(Solution)]()
5. [Largest Sum Contiguous Subarray in Range](https://practice.geeksforgeeks.org/problems/largest-sum-contiguous-subarray-in-range-1587115620/1) [(Solution)]()
6. [Range LCM Queries](https://practice.geeksforgeeks.org/problems/range-lcm-queries3348/1) [(Solution)]()


## More problems


## Further reading

