inp=lambda:map(int,input().split())
for _ in range(int(input())):
    n,k=inp()

    print(n+k)