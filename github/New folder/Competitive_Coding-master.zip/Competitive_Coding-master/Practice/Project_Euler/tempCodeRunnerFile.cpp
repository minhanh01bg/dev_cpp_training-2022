isPalindrome(result)){
                cout<<result<<endl;
                break;
            }