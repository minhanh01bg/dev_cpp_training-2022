#include<iostream>
int main()
{
    long a , b, c;
    std::cin>>a>>b>>c;
    std::cout<<a-b-c<<"\n";
}
