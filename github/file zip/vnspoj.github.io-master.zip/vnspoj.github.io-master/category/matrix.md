---
layout: posts_by_category
categories: matrix
title: Matrix - Ma trận & Kỹ thuật nhân ma trận
permalink: /category/matrix
---