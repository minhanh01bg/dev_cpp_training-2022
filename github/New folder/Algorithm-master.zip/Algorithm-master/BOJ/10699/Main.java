/* 
 * Author: Kim Min-Ho (ISKU)
 * Date: 2016.08.02
 * email: minho1a@hanmail.net
 * 
 * https://github.com/ISKU/Algorithm
 * https://www.acmicpc.net/problem/10699
 */

import java.util.Date;
import java.text.SimpleDateFormat;

public class Main {
	public static void main(String args[]) {
		System.out.println(new SimpleDateFormat("yyyy-MM-dd").format(new Date()).toString());
	}
}