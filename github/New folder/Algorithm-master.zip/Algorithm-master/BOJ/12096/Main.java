/* 
 * Author: Kim Min-Ho (ISKU)
 * Date: 2017.02.23
 * Email: minho1a@hanmail.net
 * 
 * https://github.com/ISKU/Algorithm
 * https://www.acmicpc.net/problem/12096
 */

public class Main {
	public static void main(String... args) {
		System.out.print("070-7847-5693");
	}
}