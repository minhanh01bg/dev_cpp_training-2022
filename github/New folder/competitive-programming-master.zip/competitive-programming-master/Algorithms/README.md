# Classic Algorithms and Data Structures

Some algorithms and data structures are implemented in C++ programming language.
They're usually needed in being prepared for ACM-ICPC or IOI related things.