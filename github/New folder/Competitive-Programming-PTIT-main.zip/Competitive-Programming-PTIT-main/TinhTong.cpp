#include <iostream>
using namespace std;
int main()
{
    int N;
    cin>>N;
    while(N--)
    {
        long long a;
        cin>>a;
        cout<<((a+1)*a)/2<<endl;
    }
}
