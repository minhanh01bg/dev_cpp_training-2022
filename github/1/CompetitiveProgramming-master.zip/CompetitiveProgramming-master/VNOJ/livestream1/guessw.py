s = 'april fool'
n = int(raw_input()) - 1
print s[n % len(s)]
