VONNY - VONNY AND HER DOMINOS

Cho 28 quân bài domino được đánh nhãn (0,0),(0,1),(0,2),(0,3),(0,4),(0,5),(0,6), (1,1),(1,2),...,(5,5),(5,6),(6,6) và ma trận 8x8 chứa các số. Hãy tìm ra số lượng cách đặt các quân bài domino để phủ kín ma trận và các quân bài domino chỉ được sử dụng 1 lần.
Giải thuật:
- Mỗi quân bài domino có thể đặt theo chiều ngang và chiều dọc.
- Dùng 1 ma trận để kiểm tra quân domino đó đã được dùng hay chưa.
- Quân domino (x,y) luôn có x<=y vì vậy khi đặt quân domino hãy tìm ra giá trị min của 2 số đó.
