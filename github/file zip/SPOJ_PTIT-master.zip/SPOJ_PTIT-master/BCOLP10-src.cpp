#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;
string a, b;
long n;
main()
{
	cin  >> a >> b;
	n = rand() % 9999;
	cout << n;
}