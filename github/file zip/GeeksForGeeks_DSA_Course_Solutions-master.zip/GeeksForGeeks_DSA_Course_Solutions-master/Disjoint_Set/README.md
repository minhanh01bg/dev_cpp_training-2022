
# Disjoint Set


## Problems and notes

1. [Union-Find](https://practice.geeksforgeeks.org/problems/union-find/1) [(Solution)]()
2. [Number of Connected Components](https://practice.geeksforgeeks.org/problems/number-of-connected-components/1) [(Solution)]()
3. [Detect Cycle using DSU](https://practice.geeksforgeeks.org/problems/detect-cycle-using-dsu/1) [(Solution)]()
4. [Minimum Spanning Tree using Kruskal](https://practice.geeksforgeeks.org/problems/minimum-spanning-tree3233/1) [(Solution)]()



## More problems


## Further reading


