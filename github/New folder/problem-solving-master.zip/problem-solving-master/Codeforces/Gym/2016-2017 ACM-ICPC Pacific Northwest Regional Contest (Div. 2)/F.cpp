#include <bits/stdc++.h>
 
using namespace std;
 
int main(){
	char a,p,b,e,c;
	cin >> a >> p >> b >> e >> c;
	if(a + b - '0' == c) cout << "YES" << endl;
	else cout << "NO" << endl;
}
