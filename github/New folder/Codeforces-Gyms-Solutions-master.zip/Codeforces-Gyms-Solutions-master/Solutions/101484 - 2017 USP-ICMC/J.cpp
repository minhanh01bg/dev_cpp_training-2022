// 101484 - 2017 USP-ICMC
// 101484J

#include <bits/stdc++.h>
using namespace std;

int main() {
  ios_base::sync_with_stdio(0), cin.tie(0);
  long long a, b; cin >> a >> b;
  cout << max(a, b) << endl;
  return 0;
}
