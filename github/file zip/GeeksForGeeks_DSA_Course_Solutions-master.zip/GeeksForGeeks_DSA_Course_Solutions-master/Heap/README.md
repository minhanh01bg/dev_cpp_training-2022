
# Heap


## Problems and notes

1. ^ [Binary Heap Operations](https://practice.geeksforgeeks.org/problems/operations-on-binary-min-heap/1) [(Solution)]()
2. [Heap Sort](https://practice.geeksforgeeks.org/problems/heap-sort/1) [(Solution)]()
3. [K largest elements](https://practice.geeksforgeeks.org/problems/k-largest-elements3736/1) [(Solution)]()
4. [Kth largest element](https://practice.geeksforgeeks.org/problems/kth-largest-element5034/1) [(Solution)]()
5. [Kth smallest element](https://practice.geeksforgeeks.org/problems/kth-smallest-element5545-1587115620/1) [(Solution)]()
6. ^ [Kth largest element in a stream](https://practice.geeksforgeeks.org/problems/kth-largest-element-in-a-stream-1587115620/1) [(Solution)]()
7. [K Most occurring elements](https://practice.geeksforgeeks.org/problems/most-occurring-elements-1587115620/1) [(Solution)]()
8. ^ [Minimum Cost of ropes](https://practice.geeksforgeeks.org/problems/minimum-cost-of-ropes-1587115620/1) [(Solution)]()
9. ^ [Nearly sorted](https://practice.geeksforgeeks.org/problems/nearly-sorted-1587115620/1) [(Solution)]()
10. ^ [Merge k Sorted Arrays](https://practice.geeksforgeeks.org/problems/merge-k-sorted-arrays/1) [(Solution)]()
11. ^ [Rearrange characters](https://practice.geeksforgeeks.org/problems/rearrange-characters5322/1) [(Solution)]()
12. ^ [Find median in a stream](https://practice.geeksforgeeks.org/problems/find-median-in-a-stream-1587115620/1) [(Solution)]()


## More problems



## Further reading