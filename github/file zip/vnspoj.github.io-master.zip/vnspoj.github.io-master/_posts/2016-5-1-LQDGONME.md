---
layout: post
title:  "LQDGONME - Dãy con chung dài nhất (new ver)"
categories: [dp, brute-force]
code: LQDGONME
src: LQDGONME.cpp
codeforces: https://codeforces.com/group/FLVn1Sc504/contest/274501/problem/L
---



  


Cho m dãy là hoán vị của n số tự nhiên đầu tiên

Tìm độ dài dãy con chung dài nhất của m dãy đó

#### Input

Dòng đầu chứa số hai số nguyên n và m (1≤n≤1000,1≤m≤10)

M dòng sau mỗi dòng chứa n số nguyên là dãy hoán vị của n số tự nhiên đầu tiên

#### Output

Đưa là độ dài lớn nhất của dãy con chung

#### Example

```
Input  
5 3  
1 5 3 4 2  
1 3 4 2 5  
3 1 5 4 2  
  
Output  
3  
  
Dãy con chung dài nhất là 1,4,2  

```

<!--more-->

