## Things to do this week

- [ ] Solving 15 B problems from, where solve <= 3000 [CF](http://codeforces.com/problemset)
- [ ] Solving 15 C problems, where solve >= 1000
- [ ] Solving 10 D problems, where solve >= 1000