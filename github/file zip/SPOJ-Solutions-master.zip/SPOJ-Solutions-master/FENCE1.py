import math

while True:
    l = float(input())
        if l == 0:
            break
        print('%.2f' %(l * l / math.pi / 2))
