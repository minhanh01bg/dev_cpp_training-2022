#include<iostream>
#include<string>
using namespace std;
int main(){
	string str;
	getline(cin,str);
	cout<<str.length()-1;
return 0;
}
 
