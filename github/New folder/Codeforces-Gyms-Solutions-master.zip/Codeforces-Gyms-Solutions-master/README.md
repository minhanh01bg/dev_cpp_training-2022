# Codeforces' Gyms' Solutions

Codeforces Handle: [wewark](http://codeforces.com/profile/wewark)
