---
layout: post
title:  "MBEEWALK - Bee Walk"
categories: [bfs, queue, graph]
code: MBEEWALK
src: MBEEWALK.cpp
codeforces: https://codeforces.com/group/FLVn1Sc504/contest/274505/problem/I
---



  






```
Đếm số cách đi của của 1 con ong. Nó bắt đầu từ tổ của nó, đi ra ngoài 
và đi về tổ ở bước thứ n. Ở mỗi ô, nó có thể đi sang 1 trong 6 ô kề cạnh.

```

[![Image and video hosting by TinyPic](https://vn.spoj.com/content/simes:mbeewalk.jpg)](http://tinypic.com)

#### Input

```
Dòng đầu ghi số test, mỗi dòng tiếp theo là 1 test, gồm 1 số n, 1 ≤ n ≤ 14.

SAMPLE INPUT
2
2
4

```

#### Output

```
 
Mỗi kết quả ghi trên 1 dòng, kết quả <= 2^31.

SAMPLE OUTPUT
6
90

```

<!--more-->

