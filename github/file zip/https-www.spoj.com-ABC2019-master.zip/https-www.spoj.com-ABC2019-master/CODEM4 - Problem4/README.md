https://github.com/grandpriest/Spoj-And-Codeforces-Gym-Codes/blob/master/CODEM4%20-%20Problem4.cpp

https://github.com/se7kazi/SPOJ/blob/master/CODEM4.cpp
