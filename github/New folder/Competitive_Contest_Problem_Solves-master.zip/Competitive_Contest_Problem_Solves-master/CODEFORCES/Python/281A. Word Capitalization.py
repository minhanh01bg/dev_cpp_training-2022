s = input()

sr = s[0].capitalize()

print(sr+s[1:])
