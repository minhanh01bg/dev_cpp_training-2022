/* 
 * Author: Minho Kim (ISKU)
 * Date: 2017.09.28
 * E-mail: minho1a@hanmail.net
 * 
 * https://github.com/ISKU/Algorithm
 * https://www.acmicpc.net/problem/14581
 */

import java.util.*;

public class Main {
	public static void main(String... args) {
		System.out.println(":fan::fan::fan:");
		System.out.println(":fan::" + new Scanner(System.in).next() + "::fan:");
		System.out.println(":fan::fan::fan:");
	}
}