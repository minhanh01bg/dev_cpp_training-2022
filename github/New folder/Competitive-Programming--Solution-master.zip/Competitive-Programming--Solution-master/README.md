

This is an public repository for **Accepted solutions** of coding problems on different coding platforms
like codeforces , hackerearth, codechef , hackerrank .......





# If you want to contribute

* Select the platform (eg hackerearth) 
* select appropriate *section* (like maths) 
* give **problem link** or **problem** and write code
* Refer [this ](https://github.com/jitendrajat10099/Competitive-Programming--Solution/blob/master/Hackerearth/Stack/Capital_of_Hills.cpp)as format 

if any section is not found you can create it
    

- If you found an error in any problem you can commit them ..
