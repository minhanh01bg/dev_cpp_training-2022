
# Backtracking


## Problems and notes

* [Rat Maze With Multiple Jumps](https://practice.geeksforgeeks.org/problems/rat-maze-with-multiple-jumps-1587115621/1) [(Solution)]()
* [Black and White](https://practice.geeksforgeeks.org/problems/black-and-white-1587115620/1) [(Solution)]()
* ^ [Combination Sum](https://practice.geeksforgeeks.org/problems/combination-sum-1587115620/1) [(Solution)]()
* ^ [Subsets](https://practice.geeksforgeeks.org/problems/subsets-1587115621/1) [(Solution)]()
* ^ [M-Coloring Problem](https://practice.geeksforgeeks.org/problems/m-coloring-problem-1587115620/1) [(Solution)]()
* ^ [Solve the Sudoku](https://practice.geeksforgeeks.org/problems/solve-the-sudoku-1587115621/1) [(Solution)]()


## Further reading
