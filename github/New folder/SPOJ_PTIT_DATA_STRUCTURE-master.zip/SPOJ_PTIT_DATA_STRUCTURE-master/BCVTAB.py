a , b = input().split()
a,b = int(a) , int(b)
print(int(a+b)) 
