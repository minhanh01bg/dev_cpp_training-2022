for i in range(10):
    N = int(input())
    M = int(input())
    a, b = ((N + M) // 2, (N - M) // 2)
    print(a)
    print(b)