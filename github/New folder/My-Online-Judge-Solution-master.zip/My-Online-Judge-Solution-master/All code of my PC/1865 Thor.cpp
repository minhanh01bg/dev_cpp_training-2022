#include<bits/stdc++.h>
using namespace std;
int main()
{
    string s;
    int n,i,m;
    cin>>n;
    while(n--)
    {
        getchar();
        cin>>s>>m;
        if(s=="Thor") cout<<"Y"<<endl;
        else cout<<"N"<<endl;
    }
    return 0;
}
