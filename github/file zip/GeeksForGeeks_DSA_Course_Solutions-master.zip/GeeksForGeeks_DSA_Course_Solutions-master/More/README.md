# More problems

## Problems and notes:
1. @ [The painter's partition problem](https://practice.geeksforgeeks.org/problems/the-painters-partition-problem/0)
2. ^ [Replace 0s with 5 in an integer](https://practice.geeksforgeeks.org/problems/replace-all-0s-with-5/1/) [(Solution)](https://github.com/thecoducer/GeeksForGeeks_DSA_Course_Solutions/blob/master/More/replace_zero_with_five.cpp)
3. Inner reducing pattern [(Solution)](https://ideone.com/qcrqjA)



## Further reading
- 
