t = int(input())
 
for i in range(t):
    z = input()
    if z == z[::-1] :
        print("YES")
    else:
        print("NO") 
