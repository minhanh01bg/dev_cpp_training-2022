#include<bits/stdc++.h>
using namespace std;
int main()
{
    char c;
    while(cin>>c)
    {
        if(islower(c))
            cout<<c<<endl;
    }
    return 0;
}
