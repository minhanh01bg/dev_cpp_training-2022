#include<bits/stdc++.h>
using namespace std;

int main(){
	ios_base::sync_with_stdio(false);
	int N, a, b, c;
	long long int Q, i, j;
	
	cin>>N;
	matrix[N][N];
	
	for(i=0; i<N; i++){
		for(j=0; j<N;j++){
			cin>>matrix[i][j];
		}
	}
	
	cin>>Q;
	for(i=0; i<Q; i++){
		cin>>
	}
}
