## Things to do this month

> Data structures advanced, Segment tree, DSU, 2 pointers, BIT, Segment tree of vectors

- [ ] Is there a value v in range L,R with segment tree?
- [ ] Todo [UVA BIT/2 pointer](https://uva.onlinejudge.org/index.php?option=com_onlinejudge&Itemid=8&page=show_problem&problem=4435)
- [ ] Covering all materials + problems for segment tree material in hangout group for team
- [ ] Solving all the problems for segment tree contest
- [ ] Making a trick book/template for segment tree variation/tricks, DSU tricks, 2 pointers/BIT tricks 
