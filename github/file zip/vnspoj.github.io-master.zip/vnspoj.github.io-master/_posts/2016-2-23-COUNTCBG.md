---
layout: post
title:  "COUNTCBG - "
categories: []
code: COUNTCBG
src: COUNTCBG.cpp
---



Với 1 số tự nhiên N(1<= N <= 10^9) ta có thể phân tích nó thành tổng của một số số tự nhiên liên tiếp( tất nhiên những số này phải nhỏ hơn N). Ví dụ với N = 5 ta có duy nhất 1 cách phân tích là 5 = 2+3. Bài toán đặt ra là cho số tự nhiên N, hãy cho biết có bao nhiêu cách phân tích số tự nhiên N thành tổng của các số tự nhiên liên tiếp.

#### Input

Gồm nhiều dòng, mỗi dòng chứa một số nguyên N. (Giới hạn : số dòng <= 100)

#### Output

Mỗi dòng ghi một số nguyên là số cách phân tích số N đọc được ở dòng tương ứng trong input.

#### Ví dụ

```
Input
12
5
4
13
45
100
234
3
175

Output
1
1
0
1
5
2
5
1
5

```

<!--more-->

