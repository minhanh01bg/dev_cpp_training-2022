# SPOJ_PTIT

#Each solutions for link : http://www.spoj.com/PTIT/problems/{Solution}
For ex : ALGOPRO1-src.cpp for http://www.spoj.com/PTIT/problems/ALGOPRO1/
Thanks for watching!!!!!1
