#include<bits/stdc++.h>
using namespace std;
#define ll long long
int n,m,dp[2002],mod=1000000007,ball[]={0,1,2,3,4,5,6};
int fun(int run, int idx)
{
    int i,j;
    for(i=0;i<7;i++)
    {

    }
    return dp[n];
}
int main()
{
    int T,t=1;
    scanf("%d",&T);
    while(T--)
    {
        memset(dp,0,sizeof(dp));
        scanf("%d%d",&n,&m);
        dp[1]=6;
        printf("Case %d: %d\n",t++,fun(0,0));
    }
    return 0;
}

