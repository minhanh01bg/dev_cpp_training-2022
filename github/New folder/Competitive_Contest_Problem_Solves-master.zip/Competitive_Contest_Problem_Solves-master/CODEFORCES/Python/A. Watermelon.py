x = int(input())
if x % 2 == 0 and x >= 4:
    print("YES")
else:
    print("NO")
