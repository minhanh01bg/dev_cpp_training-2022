/* 
 * Author: Kim Min-Ho (ISKU)
 * Date: 2016.08.02
 * email: minho1a@hanmail.net
 * 
 * https://github.com/ISKU/Algorithm
 * https://www.acmicpc.net/problem/11942
 */

public class Main {
	public static void main(String args[]) {
		System.out.println("고려대학교");
	}
}