/* 
 * Author: Kim Min-Ho (ISKU)
 * Date: 2016.08.17
 * email: minho1a@hanmail.net
 * 
 * https://github.com/ISKU/Algorithm
 * https://www.acmicpc.net/problem/11506
 */

public class Main {
	public static void main(String args[]) {
		System.out.println("EFBFBD"); // closed
	}
}