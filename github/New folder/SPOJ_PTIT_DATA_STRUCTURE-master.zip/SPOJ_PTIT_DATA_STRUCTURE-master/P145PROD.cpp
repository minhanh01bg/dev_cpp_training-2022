#include<iostream>
#include<math.h>
#include<stdio.h>
#define pi 2*acos(0)
using namespace std;
int main(){
	int n;
	cin>>n;
	printf("%lf\n",pow(n,2)*pi);
	printf("%lf",double(n)*double(n)*2);
return 0;
}
 
 
