inp=lambda:map(int,input().split())
n,k = inp()
t = int(input())
l = list(inp())