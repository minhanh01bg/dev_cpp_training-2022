/* 
 * Author: Kim Min-Ho (ISKU)
 * Date: 2016.07.26
 * email: minho1a@hanmail.net
 * 
 * https://github.com/ISKU/Algorithm
 * https://www.acmicpc.net/problem/1237
 */

public class Main {
	public static void main(String args[]) {
		System.out.println("문제의 정답");
    }
}