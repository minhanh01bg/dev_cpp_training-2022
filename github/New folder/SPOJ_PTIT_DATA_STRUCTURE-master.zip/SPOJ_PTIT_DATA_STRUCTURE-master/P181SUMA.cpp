#include <stdio.h>
 
int main(){
	long long k, n;
	scanf("%lld",&k);
	n=3*k+2;
	printf("%lld",n);
	return 0;
} 
