#include <bits/stdc++.h>

using namespace std;

int main() {
    std::ios::sync_with_stdio(false); cin.tie(nullptr);

    int num, res = 0;
    while (cin >> num) {
        res += num;
    }
    cout << res << endl;
    
    return 0;
}
