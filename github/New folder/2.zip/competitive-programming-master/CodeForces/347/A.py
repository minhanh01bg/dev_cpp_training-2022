a, b = [int(c) for c in input().split()]

if a == b:
    result = a
else:
    result = 1

print(result)
