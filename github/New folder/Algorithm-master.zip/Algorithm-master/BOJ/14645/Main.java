/* 
 * Author: Minho Kim (ISKU)
 * Date: 2017.07.21
 * E-mail: minho1a@hanmail.net
 * 
 * https://github.com/ISKU/Algorithm
 * https://www.acmicpc.net/problem/14645
 */

public class Main {
	public static void main(String... args) {
		System.out.printf("비와이");
	}
}