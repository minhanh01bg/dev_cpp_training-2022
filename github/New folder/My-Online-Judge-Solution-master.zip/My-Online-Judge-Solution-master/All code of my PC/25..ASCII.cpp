#include<stdio.h>

int main()
{
int y;
char ch;
printf("Enter any character:");
scanf("%c",&ch);

    y=ch;

    printf("ASCII value=%d\n",y);

    return 0;

}
