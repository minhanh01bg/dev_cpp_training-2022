git add .
git commit
git push
