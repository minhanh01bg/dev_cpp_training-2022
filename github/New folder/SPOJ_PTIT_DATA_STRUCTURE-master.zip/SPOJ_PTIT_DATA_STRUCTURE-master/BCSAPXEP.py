n = int(input())
a = []
 
for i in range(0,n):
    tmp = int(input())
    a.append(tmp)
a.sort()
 
for i in a:
    print(i) 
