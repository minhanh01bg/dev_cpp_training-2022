#include <iostream>
     
using namespace std;
     
int main() {
    int n;
    cin >> n;
        
    cout << (n * 800) - (n / 15 * 200) << endl;
        
    return 0;
}
