# Editorial

---------------------------------------------------------------------------------------------

## Problem K

> Tags : Implementation, Brute Force

> Difficulty : Easy

**Solution idea :**

 * Just place all pairs of tiles in all possible orientation
 * Report the maximum area that comes from some pair
 
*Lots of if else s, don't miss any*
   
   
   
---------------------------------------------------------------------------------------------

## Problem C

> Tags : Implementation, Brute Force, Mathematics

> Difficulty : Easy

**Solution idea :**

 * As, n = 125000. so, the loop variables can't exceed 50.
 * Do some pruning.
 
*Don't count repetition*