/*
	SubmissionId	:	3973182
	ContestId	:	322
	Index	:	A
	ProblemName	:	Ciel and Dancing
	ProblemTags	:	['greedy']
	ProgrammingLanguage	:	GNU C++
	Verdict	:	OK
*/

//
#include<iostream>
#include<iomanip>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<vector>
#include<map>
#include<set>
#include<list>
#include<queue>
#include<fstream>
#include<sstream>

using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
#define X first
#define Y second
#define pb push_back
#define mp make_pair
#define SZ(x) ((int)((x).size()))
#define ALL(x) (x).begin(), (x).end()
#define debug(x) cerr << #x << " = " << x << endl
#define FOREACH(i, c) for(__typeof((c).begin()) i = (c).begin(); i != (c).end(); i++)
#define FOR(i, a, n) for(__typeof(n) i = (a); i <= (n); i++)
#define FORD(i, n, a) for(__typeof(n) i = (n); i >= (a); i--)

int main()
{
    int g, b;
    vector<pii> v;
    cin >> b >> g;
    FOR (i, 1, g)
        v.pb(mp(1, i));
    FOR (i, 2, b)
        v.pb(mp(i, 1));
    cout << SZ(v) << endl;
    FOR (i, 0, SZ(v) - 1)
        cout << v[i].X << " " << v[i].Y << endl;
	return 0;
}
