# Competitive-Programming
This repo contains solution to some of the problems I solved in different 'OJ's.


## LightOJ Solution Ideas

[Solution Tricks](https://github.com/zabir-nabil/Competitive-Programming/tree/master/LightOJ)


