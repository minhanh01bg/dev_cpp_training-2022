import math

i=lambda:map(int,input().split())
m, n=i()

print(math.floor(m*n/2))
