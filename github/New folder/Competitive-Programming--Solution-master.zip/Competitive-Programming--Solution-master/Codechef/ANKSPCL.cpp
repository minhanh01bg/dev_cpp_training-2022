
#include<iostream>
using namespace std;
int main()
{
    long long int t,b;
    char a;
    cin>>t;
    while(t--)
    {
        cin>>a;
        b=int(a);
        b=b-97;
                cout<<b<<endl;
    }
}

