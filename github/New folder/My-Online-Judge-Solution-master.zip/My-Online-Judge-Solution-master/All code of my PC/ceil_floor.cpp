#include<bits/stdc++.h>
using namespace std;
int main()
{
    int a=5;
    double m=(double)a/2;
    cout<<ceil(m)<<endl;
    cout<<floor(m)<<endl;
    return 0;
}
