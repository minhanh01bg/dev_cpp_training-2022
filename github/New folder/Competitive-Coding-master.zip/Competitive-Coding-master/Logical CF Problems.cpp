http://codeforces.com/problemset/problem/844/D
https://codeforces.com/problemset/problem/389/E
https://codeforces.com/problemset/problem/450/E
https://codeforces.com/contest/549/problem/C
