/*
	SubmissionId	:	5600874
	ContestId	:	50
	Index	:	A
	ProblemName	:	Domino piling
	ProblemTags	:	['greedy', 'math']
	ProgrammingLanguage	:	GNU C++
	Verdict	:	OK
*/

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int a, b;
    cin >> a >> b;
    cout << a * b / 2 << endl;
}