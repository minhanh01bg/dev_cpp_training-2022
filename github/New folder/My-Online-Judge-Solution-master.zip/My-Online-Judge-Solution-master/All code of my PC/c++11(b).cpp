#include<bits/stdc++.h>
using namespace std;
void f(int &a)
{
    a=a+20;
}
int main()
{
    int a=10;
    f(a);
    cout<<"main : "<<a<<endl;
    return 0;
}


