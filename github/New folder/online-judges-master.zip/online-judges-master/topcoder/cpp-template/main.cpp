/*
Problem Name:   {name}
Used In:        {usedIn}
Used As:        {useAd}
Categories:     {categories}

{URL}
*/

using namespace std;

class CLASS_NAME {
public:

};
