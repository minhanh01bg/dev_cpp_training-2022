import sys

print(2)
judgeresponse = int(input())
sys.stdout.flush()
if judgeresponse == 3:
    print(1)
else:
    print(3)
sys.stdout.flush()