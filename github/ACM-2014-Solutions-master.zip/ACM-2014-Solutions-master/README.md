# ACM 2014 Solutions


