#include<bits/stdc++.h>
using namespace std;
int main()
{
    string a,b;
    int i,j,m;
    while(cin>>a)
    {
        if((a[a.length()-1]-'0')%2)
            cout<<"Odd"<<endl;
        else cout<<"Even"<<endl;

       // cout<<endl;
    }
}
