#include <bits/stdc++.h>

using namespace std;

int main() {
    std::ios::sync_with_stdio(false); 
    cin.tie(nullptr);

    int X, A;
    cin >> X >> A;
    cout << (X < A ? 0 : 10) << "\n";
    return 0;
}