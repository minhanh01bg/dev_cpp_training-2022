---
layout: posts_by_category
categories: data-structure
title: Data Structure - Stack, Queue, Dequeue, Heap, Set, Map, Binary Search Tree
permalink: /category/data-structure
---