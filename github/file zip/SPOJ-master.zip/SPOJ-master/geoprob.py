# 2008-07-31
t=int(raw_input())
for i in range(t):
	b,c,d=([int(x) for x in raw_input().split(' ')])
	print 2*c-b-d

