#include<iostream>

using namespace std;

int main()

{

    int a;

    char s[15];

    cin>>a>>s;

    cout<<a*2<<'\n'<<s;

}