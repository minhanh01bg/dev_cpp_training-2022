/*
 * Author: Minho Kim (ISKU)
 * Date: January 22, 2018
 * E-mail: minho1a@hanmail.net
 *
 * https://github.com/ISKU/Algorithm
 * https://www.acmicpc.net/problem/11282
 */

import java.util.*;

public class Main {
	public static void main(String... args) {
		System.out.print((char) (new Scanner(System.in).nextInt() + 0xABFF));
	}
}