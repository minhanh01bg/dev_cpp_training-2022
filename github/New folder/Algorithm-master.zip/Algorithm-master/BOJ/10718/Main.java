/* 
 * Author: Kim Min-Ho (ISKU)
 * Date: 2016.08.02
 * email: minho1a@hanmail.net
 * 
 * https://github.com/ISKU/Algorithm
 * https://www.acmicpc.net/problem/10718
 */

public class Main {
	public static void main(String args[]) {
		System.out.printf("강한친구 대한육군\n강한친구 대한육군");
	}
}
