# Queue

## Problems and notes

1. ^ [Implement Queue using array](https://practice.geeksforgeeks.org/problems/implement-queue-using-array/1) [(Solution)]()
2. ^ [Operations on Queue](https://practice.geeksforgeeks.org/problems/operations-on-queue/1) [(Solution)]()
3. [Implement Queue using Linked List](https://practice.geeksforgeeks.org/problems/implement-queue-using-linked-list/1) [(Solution)]()
4. ^ [Queue Reversal](https://practice.geeksforgeeks.org/problems/queue-reversal/1) [(Solution)]()
5. ^ [Queue using two Stacks](https://practice.geeksforgeeks.org/problems/queue-using-two-stacks/1) [(Solution)]()
6. ^ [Generate Binary Numbers](https://practice.geeksforgeeks.org/problems/generate-binary-numbers-1587115620/1) [(Solution)]()
7. ^ [Reverse First K elements of Queue](https://practice.geeksforgeeks.org/problems/reverse-first-k-elements-of-queue/1) [(Solution)]()
8. ^ [Circular tour](https://practice.geeksforgeeks.org/problems/circular-tour-1587115620/1) [(Solution)]()



## More problems


## Further reading
