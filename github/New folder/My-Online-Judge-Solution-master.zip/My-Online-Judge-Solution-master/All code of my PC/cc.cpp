#include<bits/stdc++.h>
using namespace std;
int main()
{

    cout<<"The Day is Thursday and Probability is 1/7."<<endl;
    return 0;
}
