#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("asad.txt","r",stdin);
    freopen("output2.txt","a+w",stdout);   //INPUT , OUTPUT, APPEND
      // freopen("output2.txt","a",stdin);
    int a,b;
    while(cin>>a>>b)
    {
        cout<<"the sum is:"<<a+b<<endl;
    }
    return 0;
}

