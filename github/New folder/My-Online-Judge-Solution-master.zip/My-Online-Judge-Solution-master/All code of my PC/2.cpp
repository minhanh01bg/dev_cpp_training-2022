#include<bits/stdc++.h>
using namespace std;
#include<math.h>
int main()
{
    int a=578;
    a=reverse(5);
    cout<<a;
    return 0;
}
