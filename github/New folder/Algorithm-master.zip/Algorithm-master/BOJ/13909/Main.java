/*
 * Author: Minho Kim (ISKU)
 * Date: February 12, 2019
 * E-mail: minho.kim093@gmail.com
 *
 * https://github.com/ISKU/Algorithm
 * https://www.acmicpc.net/problem/13909
 */

import java.util.*;

public class Main {
	public static void main(String... args) {
		System.out.print((int) Math.sqrt(new Scanner(System.in).nextLong()));
	}
}