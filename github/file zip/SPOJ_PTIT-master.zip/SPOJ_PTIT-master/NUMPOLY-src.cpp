#include<iostream>
#include<math.h>
using namespace std;
main()
{
	long n;
	cin>>n;
	cout<< n*(n-1)*(n-2)*(n-3)/24;
}