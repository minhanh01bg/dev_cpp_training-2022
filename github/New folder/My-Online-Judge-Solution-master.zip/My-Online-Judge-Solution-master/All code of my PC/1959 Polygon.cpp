#include<bits/stdc++.h>
using namespace std;
int main()
{
    long long n,l;
    while(cin>>n>>l)
    {
        cout<<n*l<<endl;
    }
    return 0;
}
