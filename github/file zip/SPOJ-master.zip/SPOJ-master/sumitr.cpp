// 2008-07-07
// Note: remove comments in order to pass source size limit
#include<iostream>
using namespace std;
#define F(y,z) for(y=1;y<=z;y++){
#define s scanf("%d",
int main(){static int a[100][100],n,i,N,m,j,k,x;s&n);F(i,n)s&N);m=0;F(j,N)F(k,j)s&x);a[j][k]=x+max(a[j-1][k-1],a[j-1][k]);m>?=a[j][k];}}printf("%d\n",m);}}
