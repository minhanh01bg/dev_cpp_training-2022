## WA on test case 2

inp=lambda:map(int,input().split())
t = int(input())
for _ in range(t):
    n = int(input())
    n,k = inp()
    l = list(inp())