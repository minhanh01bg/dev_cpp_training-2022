/*
 * Author: Minho Kim (ISKU)
 * Date: January 22, 2018
 * E-mail: minho1a@hanmail.net
 *
 * https://github.com/ISKU/Algorithm
 * https://www.acmicpc.net/problem/11283
 */

import java.util.*;

public class Main {
	public static void main(String... args) {
		System.out.print((int) (new Scanner(System.in).next().charAt(0) - 0xABFF));
	}
}