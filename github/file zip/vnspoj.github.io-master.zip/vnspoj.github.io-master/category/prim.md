---
layout: posts_by_category
categories: prim
title: Prim - Tìm cây khung nhỏ nhất MST
permalink: /category/prim
---