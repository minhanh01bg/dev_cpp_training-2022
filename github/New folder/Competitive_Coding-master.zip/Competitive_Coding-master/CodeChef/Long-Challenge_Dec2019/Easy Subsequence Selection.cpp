#include<stdio.h>
#include<string.h>

int main(){
	int T;
	scanf("%d", &T);
	while(T--){
		int N, K;
		scanf("%d", &N);
		char str[N], A[N], B[N];
		scanf("%s", &str);
		for(int i=0; i<N; i++){
			for(int j=0; j<N; j++){
				if()
			}
		}
		
	}
	return 0;
}
