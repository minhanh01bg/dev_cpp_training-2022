#include<bits/stdc++.h>
using namespace std;
int main()
{
    string s;
    int n,i;
    while(cin>>n)
    {
        getchar();
        while(n--)
        {
            getline(cin,s);
        }
        cout<<"Ciencia da Computacao"<<endl;
    }
    return 0;
}
